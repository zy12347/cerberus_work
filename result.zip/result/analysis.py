import numpy as np
import matplotlib.pyplot as plt


def main():
    distance = np.load('distances.npy')
    distance_from_start = np.load('distances_from_start.npy')
    error_array = np.load('error_array.npy')
    timestamps = np.load('timestamps.npy')
    #errors(3,timestamps,error_array)
    print(timestamps)
    
def errors(n,timestamp,errors):
    timestamp = np.array(timestamp,dtype=int)
    curtime = timestamp[0]
    preid = 0
    accumulate = 0.0
    result = []
    indexs = []
    N = len(timestamp)
    for i in range(N):
        if(i==N-1 or timestamp[i]-curtime==n):
            curtime = timestamp[i]
            result.append(accumulate/(i-preid))
            indexs.append(curtime)
            preid = i
            accumulate = 0
        else:
            accumulate += errors[i]
    np.array(result)
    np.array(indexs)
    plt.plot(indexs,result,label="each"+str(n)+"s")
    plt.title("each"+str(n)+"s")
    plt.xlabel("time/s")
    plt.ylabel("relative_error/m")
    plt.legend()
    plt.show()
    np.savetxt("relative_error_for"+str(n)+"s.txt",result)
    pass

main()